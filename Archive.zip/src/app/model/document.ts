export interface Document {
    id: string;
    doctitle : string;
    file : string;
}