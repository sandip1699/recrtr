export interface signUp {
    email : string;
    password : string;
}